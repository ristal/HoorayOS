<?php
header('Content-Type: text/html; charset=UTF-8');
define('APIKEY','062060c9ad3746131261225d07a5d239');
define('Secret','3eab118ccbecb560');
define( "CALLBACK_URL" , 'http://hoorayos.com/demo/2.2/connect/douban/doubancallback.php' );//回调地址