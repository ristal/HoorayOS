<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>天气预报</title>
<style type="text/css">
body{margin:0;padding:0}
div{width:200px;height:290px;background:url(bg.png) no-repeat center bottom}
</style>
</head>

<body>
<div>
	<!-- http://www.thinkpage.cn/weather/widget.aspx -->
	<iframe src="http://www.thinkpage.cn/weather/weather.aspx?uid=&cid=101010100&l=zh-CHS&p=CMA&a=1&u=C&s=5&m=1&x=1&d=3&fc=FFF&bgc=&bc=&ti=1&in=1&li=2&ct=iframe" frameborder="0" scrolling="no" width="200" height="290" allowTransparency="true"></iframe>
</div>
</body>
</html>