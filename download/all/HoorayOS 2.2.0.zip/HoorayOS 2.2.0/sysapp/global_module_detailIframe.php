<div id="detailIframe" style="background:#fff;position:fixed;z-index:1;top:-100px;left:0;width:100%;height:100%;display:none">
	<iframe frameborder="0" style="width:100%;height:100%"></iframe>
</div>