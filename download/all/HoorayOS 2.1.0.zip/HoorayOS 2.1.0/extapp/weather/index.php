<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>天气预报</title>
</head>

<body>
<div>
<!-- http://www.thinkpage.cn/weather/widget.aspx -->
<iframe src="http://www.thinkpage.cn/weather/weather.aspx?uid=&cid=101010100&l=zh-CHS&p=CMA&a=1&u=C&s=5&m=1&x=1&d=3&fc=&bgc=FFFFFF&bc=C6C6C6&ti=1&in=1&li=2&ct=iframe" frameborder="0" scrolling="no" width="200" height="320" allowTransparency="true"></iframe>
</div>
</body>
</html>