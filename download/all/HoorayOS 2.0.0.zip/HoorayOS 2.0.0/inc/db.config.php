<?php
	//数据库连接配置信息
	$db_hoorayos_config = array(
		'dsn'=>'mysql:host=localhost;dbname=hoorayos',
		'name'=>'root',
		'password'=>'hooray'
	);
?>