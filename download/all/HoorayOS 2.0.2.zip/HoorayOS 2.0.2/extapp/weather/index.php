<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>天气预报</title>
<style type="text/css">
body{margin:0;padding:0;background:url(titlebg.png) no-repeat}
</style>
</head>

<body>
<div>
<iframe src="http://m.weather.com.cn/m/pn7/weather.htm" width="200" height="22" marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" scrolling="no"></iframe>
</div>
</body>
</html>