<?php
	chdir(dirname(__FILE__));
	require('inc/db.class.php');
	require('inc/functions.php');
	require('inc/config.php');
?>